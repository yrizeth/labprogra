# Ticket de salida 3

Nombre:Danae Bordones

Rol:202573056-1

Link al repositorio de GitHub (extra):https://github.com/yrizeth/labprogra.git

## Errores

### Error 1
- Tipo de error: Invalid read of size 4
- Línea del código: 19
- Corrección: se cambio este limite para que no se desborde la memoria: for(int i = 0; i < f-1; i++)

### Error 2
- Tipo de error:Invalid write of size 4
- Línea del código:68
- Corrección: se cambio esto: int *acum = malloc((f+1) * sizeof(int));

### Error 3
- Tipo de error: no se libero caja
- Línea del código:no esta
- Corrección: se agrego la libreacion de la caja for(int i = 0; i < f; i++){
        free(caja[i]);
    }
    
    free(caja);

### Error 4
- Tipo de error: 
- Línea del código:
- Corrección:

## Caso de prueba propio (case_04)

Explicación:
Fila 1: 500 + 50 + 50 = 600 en 3 monedas, promedio 200: de monedas grandes
Fila 2: 100 + 100 + 100 = 300 en 3 monedas, promedio 100
Fila 3: 100 + 100 + 100 = 300 en 3 monedas, promedio 100
600 >= 200 >= 200, asi que la caja esta ordenada
Compra 1 ($1200): alcanza solo con las tres filas
Compra 2 ($600): con la fila 1 alcanza

